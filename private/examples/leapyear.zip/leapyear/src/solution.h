#include <stdlib.h>

int leapyear(int year);
