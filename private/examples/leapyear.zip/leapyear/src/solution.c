#include "solution.h"

int leapyear(int year)
{
    
    /***** Enter solution here! *****/

}
