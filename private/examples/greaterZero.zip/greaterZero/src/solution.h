#include <stdlib.h>

int greater_than_zero(int number);
