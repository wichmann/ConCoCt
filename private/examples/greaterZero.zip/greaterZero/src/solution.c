#include "solution.h"

int greater_than_zero(int number)
{
    
    /***** Insert solution here! *****/

}
 
