 
Größer als Null
===============
 
Beschreibung
------------
Es soll eine Funktion geschrieben werden, die zurückgibt, ob eine übergebene
Zahl *größer als Null* ist.


Übergabeparameter
-----------------
zahl: int 
    Zahl, die getestet werden soll.


Rückgabewerte
-------------
1, wenn die Zahl größer als Null ist.
0, wenn die Zahl nicht größer als Null ist.
