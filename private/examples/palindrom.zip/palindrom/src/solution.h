#include <stdlib.h>

int palindrom(char* string);
