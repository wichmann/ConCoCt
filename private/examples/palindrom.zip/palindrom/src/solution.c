#include "solution.h"

int palindrom(char* string)
{
    
    /***** Enter solution here! *****/

}
