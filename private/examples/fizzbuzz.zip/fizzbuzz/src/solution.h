#include <stdlib.h>

void fizzbuzz(int number, char* string);
