#include "solution.h"

void fizzbuzz(int number, char* string)
{
    
    /***** Enter solution here! *****/

}
